<?php 

	$server = "mysql.hostinger.mx";
	$user = "u912818170_autop";
	$pwd = "Jireh.18";
	$db = "u912818170_autop";
	
	/*
	$server = "localhost";
	$user = "root";
	$pwd = "morga2";
	$db = "db_fac";*/

	$con = new mysqli($server, $user, $pwd, $db);
	if($con->connect_error)
	{
		echo $con->connect_error();
	}
?>