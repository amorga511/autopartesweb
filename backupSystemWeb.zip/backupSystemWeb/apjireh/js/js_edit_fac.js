
vTotal = 0;
vEfectivo = 0;
vTarjeta = 0;
vFacNum = '';

var appM = angular.module('appMain', ['ngCookies']);

appM.controller('appControl1', function($scope, $http, $cookies) {

	$scope.vTotal = 0;

getEmpleadosVdr();

function getEmpleadosVdr(){
    $http.post(vRutaApp +'/server/svrConsultas.php', {op:102, cargo:101}).then(function(vResult){
        //console.log('Getting Employees');
        if(vResult.data[0].cod == 1){                
            $scope.arrEmpleadosVdr=vResult.data[0].rData; 
        }else{
            alert('Error en Consultando DB');
        }
    }); 
}


$scope.close_w = function(){
	window.close();
}

$scope.calcPago = function(vFlag){
	//alert(vFlag);
	calculaPago(vFlag);
}

$scope.save_udt = function(){
	vVendedor = $("#vVendedor").val();
	vCliente = $("#vCliente").val();
	vTel = $("#vTel").val();
	vRTN = $("#vRTN").val();
	vFlag = 1;
	vF = 0;
	vMsj = '';

	vEfectivo = parseFloat($("#vEfectivo").val());
    vTarjeta = parseFloat($("#vTarjeta").val());

    if(vTel.length <= 0){
    	vF = 1;
    	vMsj = 'Telefono Incorrecto';
    }
    if(vRTN.length <= 0){
    	vF = 1;
    	vMsj = 'RTN Incorrecto';
    }
    if(vCliente.length <= 0){
    	vF = 1;
    	vMsj = 'Nombre Cliente Incorrecto';
    }
    if(vVendedor == 0){
    	vF = 1;
    	vMsj = 'Vendedor Incorrecto';
    }

    if(vF==0){
    	vDtos_udt = {"fac": vFacNum, "efec":vEfectivo, "tarj":vTarjeta, "cli":vCliente, "tel":vTel, "rtn":vRTN, "vndr":vVendedor, "f":vFlag};

	    $http.post(vRutaApp +'/server/svrTransacciones.php', {op:206, dts_udt:vDtos_udt}).then(function(vResult){

	        msjR = vResult.data.split(',');
	        if(parseInt(msjR[0])==1){
	            alert("Datos Guardados Exitosamente");
	        	window.location.reload();
	        }               
	    });
    }else{
    	alert(vMsj);
    }

    
}

$scope.anula_fac = function(){
	vFlag = 2;
	vMsj = '';
	vF = 0;
    vDescAnl = '';

    vDescAnl = $("#vDescAnular").val();

    if(vDescAnl.length < 10){
    	vF = 1;
    	vMsj = 'Ingrese Motivo Anulación de Factura';
    }

	if(vF==0){
		vDtos_udt = {"fac": vFacNum, "mAnl":vDescAnl, "f":vFlag};

		$http.post(vRutaApp +'/server/svrTransacciones.php', {op:206, dts_udt:vDtos_udt}).then(function(vResult){

	        msjR = vResult.data.split(',');
	        if(parseInt(msjR[0])==1){
	            alert("Datos Guardados Exitosamente");
	        	window.open("printFac.php?vF=" + vFacNum  ,"","width=500, height=600");
	        	window.close();
	        }               
	    });
	}else{
		alert(vMsj);
	}

    
}


function calculaPago(vT){

    if(vTotal > 0){
    	vEfectivo = parseFloat($("#vEfectivo").val());
    	vTarjeta = parseFloat($("#vTarjeta").val());

        if(parseFloat(vEfectivo)<=vTotal && vT == 1){
            vTarjeta = vTotal - vEfectivo;

			$("#vEfectivo").val(vEfectivo);
			$("#vTarjeta").val(vTarjeta); 
        }
        if(parseFloat(vTarjeta)<=vTotal && vT == 2){
            vEfectivo = vTotal - vTarjeta;

            $("#vEfectivo").val(vEfectivo);
			$("#vTarjeta").val(vTarjeta)
        }
    }     
}


});


function setVals(objDtos)
{
	//alert($("#vVendedor").val());
	$("#vVendedor").val($("#vVndr").val());
	$("#vCliente").val(objDtos.cliente);
	$("#vTel").val(objDtos.tel);
	$("#vRTN").val(objDtos.rtn);
	$("#vEfectivo").val(objDtos.efec);
	$("#vTarjeta").val(objDtos.tarj);

	vTotal = parseFloat(objDtos.efec) + parseFloat(objDtos.tarj);
	vFacNum = $("#vFac").val();
	vEfectivo = parseFloat(objDtos.efec)
	vTarjeta = parseFloat(objDtos.tar);

}

