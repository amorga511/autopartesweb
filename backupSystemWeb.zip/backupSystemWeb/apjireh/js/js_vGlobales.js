// Variable Globales

var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
//var vRutaApp = 'http://localhost/ProyectosByT/web/autopartesWeb';
var vRutaApp = 'http://autopartes.empresasjireh.com';
var appTitle = 'Facturación Auto Partes Jireh';