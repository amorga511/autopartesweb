<?php session_start(); ?>
<!DOCTYPE html>
<html ng-app="appMain">
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="../css/bootstrap.min.css" />
<link rel="stylesheet" href="../css/css_main.css" />
<link rel="stylesheet" href="../css/simple-sidebar.css" />
<?php

   /* if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: index.php");
        }
    }else{
        header("Location: index.php");
    }*/
?>
</head>
<body ng-controller="appControl1">
<div id="wrapper">
    
    <?php include 'menu.php'; ?>

    <div id="page-content-wrapper" style="padding:0px">
        <!-- Div Contenido -->
        <div class="container-fluid" style="padding:0px;">
        	<!-- Barra Superior -->
        	<?php include 'topbar.php'; ?>

            <!-- Div Contenido -->
            <div class="container-fluid c_anime_div" style="padding:20px; padding-top:60px;">
                <h2>En construccion </h2>
            </div>
            <!-- Fin Div Contenido -->
        </div><!-- Fin Dvi Contenido -->      
    </div>
</div>
</body>

<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
<!--<script type="text/javascript" src="cordova.js"></script>-->
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script src="../js/angular.min.js"></script>
<script src="../js/ngCookies.min.js"></script>
<script src="../js/js_vGlobales.js"></script>
<script type="text/javascript" src="../js/js_settings.js"></script>

</html>
