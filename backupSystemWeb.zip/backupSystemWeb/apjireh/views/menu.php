<!-- Sidebar -->
<?php
echo ' 
    <div id="sidebar-wrapper">
        <ul class="sidebar-nav">
            <li class="sidebar-brand">
                <span id="btn_close_menu" class="glyphicon glyphicon-chevron-left btn_closemenu" ng-click="btn_menu=true"></span>
                <a href="#"  ng-click="switchMenu(1)">
                        HOME
                </a>
            </li>
            <li><a href="#sbm_vtas" data-toggle="collapse">Ventas</a>
                <ul id="sbm_vtas" class="collapse" style="padding-left: 0px">
                    <li style="list-style: none;">
                        <a href="#" ng-click="switchMenu(2)" style="padding-left:15px">Caja</a>
                    </li>
                    <li style="list-style: none">
                        <a href="#" ng-click="switchMenu(3)" style="padding-left:15px">Facturacion</a>
                    </li>   
                </ul>
            </li>
           <!-- <li><a href="#sbm_finanzas" data-toggle="collapse">Finanzas</a>
                <ul id="sbm_finanzas" class="collapse" style="padding-left: 0px">
                    <li style="list-style: none;">
                        <a href="#" style="padding-left:15px">Estados de Resultados</a>
                    </li>
                </ul>
            </li>-->
            
        </ul>
    </div>';
?>
    <!-- /#sidebar-wrapper -->
