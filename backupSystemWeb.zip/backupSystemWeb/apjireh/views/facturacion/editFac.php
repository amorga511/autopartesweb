﻿<?php session_start(); ?>
<!DOCTYPE html>
<html ng-app="appMain">
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="Cache-Control" content="no-store" />

<link rel="stylesheet" href="../../css/bootstrap.min.css" />
<?php

    /*if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: ../../index.php");
        }
    }else{
        header("Location: ../../index.php");
    }*/

    if($_SESSION["login"]==0){
        $x=null;
    }else{
        $numFac = $_GET["vF"];

        $vItems = array();
        $vCantLetras = "0/100";

        $cai="";

        $rtn = "";
        $empresa = "";
        $eDir = "";
        $eTel = "";
        $eEmail = "";



        $vCliente = "";
        $vTel = "";
        $vRTN ="";
        $vCaja ="";
        $vCajero = "";
        $vCajeroName = "";
        $vFecha = "";
        $vVendedor = "";
        $vVendedorName = "";

        $vTotal = 0;
        $vSubTotalE = 0;
        $vSubTotalG = 0;
        $vDesc = 0;
        $vISV = 0;
        $vEfectivo = 0;
        $vTarjeta = 0;

        
        $facDesd="";
        $facHasta="";
        $fechLimite ="";

        include '../../server/dblink.php';

        $vQuery = "SELECT * FROM tbl_facturas where id='" .  $numFac . "'";
        if($res1 = $con->query($vQuery)){
            $rows = $res1->fetch_assoc();

            $cai = $rows["cai"];

            $vFecha = $rows["fech_fac"];
            $vCliente = $rows["cliente"];
            $vTel = $rows["tel_cliente"];
            $vRTN = $rows["rtn_cliente"];
            $vVendedor = $rows["vendedor"];
            $vCajero = $rows["cajero"];
            $vCaja = $rows["caja"];


            $vSubTotalE = $rows["subtotal_exento"];
            $vSubTotalG = $rows["subtotal_grabado"];
            $vDesc = $rows["descuento"];
            $vISV = $rows["isv"];
            $vTotal = $rows["total"];

            $vEfectivo = $rows["efectivo"];
            $vTarjeta = $rows["tarjeta"];
        }
        $vQuery = "SELECT * FROM tbl_factura_detalle where factura_id='" . $numFac . "'";
        if($res2 = $con->query($vQuery)){
            while($row2 = $res2->fetch_assoc()) {
                $sTot = (float)$row2["unidades"] * $row2["precio"];
                array_push($vItems, array("cod"=>$row2["cod_item"],"desc"=>$row2["detalle"], "und"=>$row2["unidades"],"price"=>$row2["precio"], "stot"=>$sTot));
            }
        }

        $vSQL = "SELECT * FROM tbl_cai_control where cai='" . $cai . "'";
        if($resC = $con->query($vSQL)){
            while($rowC = $resC->fetch_array()){
                //$cai = $rowC[3];
                //$rtn = $rowC[2];
                $facDesd = $rowC[4];
                $facHasta = $rowC[5];
                $fechLimite = $rowC[6];
            }
        }

        $vSQL = "SELECT * FROM tbl_tiendas";
        if($resC = $con->query($vSQL)){
            while($rowC = $resC->fetch_array()){
                //$cai = $rowC[3];
                $rtn = $rowC[5];
                $empresa = $rowC[1];
                $eDir = $rowC[2];
                $eTel = $rowC[3];
                $eEmail = $rowC[4];
            }
        }

        $vSQL = "SELECT nombre_persona FROM tbl_personal where id='" . $vCajero . "'";
        if($resC = $con->query($vSQL)){
            while($rowC = $resC->fetch_array()){
                $vCajeroName = $rowC[0];
                //$cai = $rowC[3];
                /*$rtn = $rowC[5];
                $empresa = $rowC[1];
                $eDir = $rowC[2];
                $eTel = $rowC[3];
                $eEmail = $rowC[4];*/
            }
        }

        $vSQL = "SELECT nombre_persona FROM tbl_personal where id='" . $vVendedor . "'";
        if($resC = $con->query($vSQL)){
            while($rowC = $resC->fetch_array()){
                $vVendedorName = $rowC[0];
                //$cai = $rowC[3];
                /*$rtn = $rowC[5];
                $empresa = $rowC[1];
                $eDir = $rowC[2];
                $eTel = $rowC[3];
                $eEmail = $rowC[4];*/
            }
        }

        
    }
?>

<style>
#dvBody{
    width:280px;
    /*background-color: gary;*/
}
.font1{
    font-family: 'cambria';
    font-size:16px;
    line-height: 1.3;
    padding-left: 2px;
    padding-right: 2px;
}

.font2{
    line-height: 1.3;
    font-family: 'cambria';
    font-size: 14px;
    padding-left: 2px;
    padding-right: 2px;
}

.font3{
    line-height: 1.3;
    font-family: 'cambria';
    font-size: 12px;
    text-align: middle;    
    padding: 2px;
    /*border:solid 1px;*/
}


}
</style>
</head>
<body ng-controller="appControl1">

<div style="padding: 20px">
<center>
    <br />
    <table width="100%" border="0">
        <tr>
            <td style="width:50%" align="center">
                <img src="../../img/logofac.png" width="200px" height="130px" style="margin-bottom:10px" /><br>
            </td>
            <td align="center">
                <b><div class="font1"><?= $empresa; ?></div></b>
                <div class="font2" >RTN: <?= $rtn; ?></div>
                <div class="font2"><?= $eDir; ?></div>
                <div class="font2">Tel: <?= $eTel; ?></div>
                <div class="font2">E-mail: <?= $eEmail; ?></div>
            </td>
        </tr>
        <tr>
            <td valign="top">  
                <br />  
                <table width="100%">
                    <tr>
                        <td width="22%"><b>CAI:</b></td>
                        <td width="78%"><?= $cai; ?></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><b>Desde:</b></td>
                        <td><?= $facDesd; ?></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><b>Hasta:</b></td>
                        <td><?= $facHasta; ?></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><b>Fecha Limite Emisión:</b></td>
                        <td><?= $fechLimite; ?></td>
                        <td></td>
                    </tr>
                </table>            
            </td>
            <td valign="top">
                <br />
                <div class="font1"></div>
                <div class="font1"></div>
                <div class="font1"> </div>
                <div class="font1"></div>
                <div class="font1"></div>
                <div class="font1">
                    <table width="100%">
                        <tr>
                            <td><b>Factura # </b></td>
                            <td><input type="text" style="margin-bottom: 5px; width: 90%" class="form-control" id="vFac" value="<?= $numFac ?>" readonly/></td></td>
                        </tr>
                        <tr>
                            <td><b>Fecha:</b></td>
                            <td><?= $vFecha ?></td>
                        </tr>
                        <tr>
                            <td><b>Caja:</b></td>
                            <td><?= $vCaja ?></td>
                        </tr>
                        <tr>
                            <td><b>Cajero:</b></td>
                            <td><?= $vCajeroName ?></td>
                        </tr>
                        <tr>
                            <td><b>Vendedor:</b></td>
                            <td>
                                <input type="text" value=<?= $vVendedor; ?> id="vVndr" hidden/>
                                <select class="form-control" id="vVendedor" ng-model="vVendedor">
                                     <option value="{{ row2.id }}" ng-repeat="row2 in arrEmpleadosVdr">{{ row2.name }}</option>
                                </select>                            
                            </td>
                        </tr>

                    </table>
                </div>
            </td>
        </tr>
    </table>
    <br />

    <table width="100%">
        <tr>
            <td width="33%"><b>Nombre Cliente:</b>
            <input type="text" style="margin-bottom: 5px; width: 90%" class="form-control" id="vCliente" ng-model="vCliente"/></td>
            <td width="33%"><b>Telefono Cliente:</b>
            <input type="number" style="margin-bottom: 5px; width: 90%" class="form-control" id="vTel" ng-model="vTel"/></td>
            <td><b>RTN Cliente:</b>
            <input type="number" style="margin-bottom: 5px; width: 90%" class="form-control" id="vRTN" ng-model="vRTN"/></td>
        </tr>
    </table>

    <div class="font1" style="border-bottom: solid 1px gray; margin: 0px">-</div>
    <div class="row" style="margin: 0px; padding-bottom:2px; border-bottom: solid 1px gray;">
        <!--<div class="col-xs-2 font2">Cod.</div>-->
        <div class="col-xs-6 font2">Descript</div>
        <div class="col-xs-2 font2">Unds.</div>
        <div class="col-xs-2 font2">Precio</div>
        <div class="col-xs-2 font2">S.Total</div>
    </div>
<?php
    for($i=0;$i<count($vItems); $i++){
    echo "<div class=\"row\" style=\"margin: 5px;\">
        <div class=\"col-xs-6 font3\" style=\"text-align:left;\">". $vItems[$i]["desc"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["und"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["price"] ."</div>
        <div class=\"col-xs-2 font3\" style=\"text-align:right;\"><span\">". $vItems[$i]["stot"] ."</span></div>
        </div>";
    
    /*echo "<div class=\"row\" style=\"margin: 0px;\">
        <div class=\"col-xs-2 font3\">". $vItems[$i]["cod"] ."</div>
        <div class=\"col-xs-4 font3\">". $vItems[$i]["desc"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["und"] ."</div>
        <div class=\"col-xs-2 font3\">". $vItems[$i]["price"] ."</div>
        <div class=\"col-xs-2 font3\" style=\"text-align:right;\"><span\">". $vItems[$i]["stot"] ."</span></div>
        </div>";*/
    }
?>
    <div class="row font1" style="margin: 0px; margin-top:7px; padding-top: 5px; border-top: solid 1px gray; text-align: right;">
        <div class="col-xs-7 " >S. Tot. Exento L.</div>
        <div class="col-xs-5 " style="padding-right:2px"><?= $vSubTotalE ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div class="col-xs-7 " >S. Tot. Grabado L.</div>
        <div class="col-xs-5 " style="padding-right:2px"><?= $vSubTotalG ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div class="col-xs-7 ">Descuento L.</div>
        <div class="col-xs-5 " style="padding-right:2px"><?= $vDesc ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div class="col-xs-7 ">ISV L.</div>
        <div class="col-xs-5 " style="padding-right:2px"><?= $vISV ?></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div class="col-xs-7" style="padding-top:5px"><b>TOTAL L.</b></div>
        <div class="col-xs-5" style="border-top: solid 1px gray; padding-right:2px; padding-top:5px"><b><?= $vTotal ?></b></div>
    </div>

    <div class="row font1" style="margin: 0px; text-align: right; margin-top: 8px">
        <div class="col-xs-7" style="padding-top:0px"><b>EFECTIVO L.</b></div>
        <div class="col-xs-5" style="padding-right:2px"><b><input type="number" style="margin-bottom: 5px; width: 100%; text-align: right;" class="form-control" id="vEfectivo" ng-model="vEfectivo" ng-blur="calcPago(1)"/></b></div>
    </div>
    <div class="row font1" style="margin: 0px; text-align: right;">
        <div class="col-xs-7" style=""><b>TARJETA L.</b></div>
        <div class="col-xs-5" style="padding-right:2px"><b><input type="number" style="margin-bottom: 5px; width: 100%; text-align: right;" class="form-control" id="vTarjeta" ng-model="vTarjeta" ng-blur="calcPago(2)"/></b></div>
    </div>
    <br />
    
    <br />
    <table width="100%">
        <tr>
            <td>
                <b>Motivo Anulación Factura:</b>
                <textarea style="margin-bottom: 20px; width: 90%" class="form-control" id="vDescAnular" ng-model="vDescAnular"/></textarea>
            </td>
        </tr>
        <tr>
            <td width="40%"></td>
            <td align="right"> <input type="button" id="btn_save_edit" value="Guardar Cambios" class="btn btn-success" ng-click="save_udt()" />
            <input type="button" id="btn_save_edit" value="Anular Factura" class="btn btn-danger" ng-click="anula_fac()" />
            <input type="button" id="btn_save_edit" value="Cerrar" class="btn btn-default" ng-click="close_w()" />
            </td>
        </tr>
    </table>
    <br />
</center>
</div>

</body>

<script type="text/javascript" src="../../js/jquery-3.1.1.min.js"></script>
<!--<script type="text/javascript" src="cordova.js"></script>-->
<script type="text/javascript" src="../../js/bootstrap.min.js"></script>


<script src="../../js/angular.min.js"></script>
<script src="../../js/ngCookies.min.js"></script>
<script src="../../js/js_vGlobales.js"></script>
<script src="../../js/js_numTostr.js"></script>
<script type="text/javascript" src="../../js/js_edit_fac.js"></script>
<script type="text/javascript">

    objDtos = {"cliente":'<?= $vCliente ?>', "tel": <?= $vTel ?>, "rtn": <?= $vRTN ?>, "vndr":<?= $vVendedor; ?>, "tarj":<?= $vTarjeta ?>, "efec":<?= $vEfectivo ?>}
    setTimeout(function(){setVals(objDtos); }, 800);
</script>

</html>
