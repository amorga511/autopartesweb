<?php
echo '<div class="col-xs-12 barra_sup_css" style="padding:0px;">
                <div class="col-xs-1" style="padding: 5px">
                <span id="btn_menu" class="glyphicon glyphicon-menu-hamburger btn_menu_c" ng-click="btn_menu=false" ng-show="btn_menu"></span>
                </div>
                <div class="col-xs-7" style="padding-top:14px">
        		<!--<img src="img/menu.png" id="btn_menu" width="35px" height="35px" />-->
        		<center><span id="title" style="font-size: 16px;">{{ apptitle }}</span></center>

                
                </div>
                <div  style="float:right;">
                <span style="font-size: 15px"><span id="userTopbar">user</span> | <a href="#" ng-click="switchMenu(99)">Cerrar Sesion </a></span>
                <span class="glyphicon glyphicon-cog" style="cursor:pointer; margin:10px;color:#D8D8D8; font-size:1.7em" ng-click="switchMenu(98)"></span>
                </div>        		
        	</div>';


?>