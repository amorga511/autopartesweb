
/*var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};*/

var appM = angular.module('appMain', ['ngCookies', 'ngTable']);

appM.controller('appControl1', function($scope,$http, $cookies, NgTableParams) {
    $scope.ISV_VAL = 0.15;
    $scope.btn_menu = false;
    $scope.cFacs = true;
    $scope.cConsultas = false;
    $scope.user_name = "Test usuario";

    $scope.vCriterioSearchF = "1";

    $scope.arr_items = [];
    $scope.arr_generales = {"cliente":"", "rtn":"", "tel":"", "nota":"", "subTotal":0, "desc":0, "isv":0, "total":0, "fecha":"", "vendedor":"NA", "cajero":"", "caja":"", "efectivo":0, "tarjeta":0};

    $scope.apptitle = appTitle;
    limpiar_fac();
    limpia_busqueda();

    if(window.innerWidth<900){
        $scope.btn_menu = true;
    }

    if(!$cookies.get(vEmpresa)){
        console.log('no login');
        window.location.replace('../../index.php');
    }else{
        validaLogin();
    }

    $scope.calcPago = function(vTipo){
        calculaPago(vTipo);       
    }

    $scope.switchMenu = function(vM){
        switch(vM){
            case 1:
                window.location.replace('../../main.php');
            break;
            case 2:               
                window.location.replace('../../views/caja/index.php');
            break;
            case 3:
                window.location.replace('../../views/facturacion/index.php');              
            break;
            case 4:
                $scope.dvInicio = false;
                $scope.dvStaff = false;
                $scope.dvPersonalOp = false;                
                window.location.reload();
            break;
            case 10:
                $scope.dvInicio = false;
                $scope.dvStaff = false;
                $scope.dvPersonalOp = false;                
                window.location.replace('../../views/admin/caicontrol.php');
            break;
            case 98:
                window.location.replace('../settings.php');
            break;
            case 99:
                console.log(vEmpresa);
                $cookies.remove(vEmpresa, {path:'/'});
                setTimeout(function(){window.location.replace('../../index.php');}, 400);

                //$http.post(vRutaApp +'/server/svrConsultas.php', {op:104}).then(function(vResult){
                  //  window.location.reload();
                //}); 
            break;
            default:
                return;
        }
        if(vM!=99){
            $("#wrapper").toggleClass("toggled");
        }
    }

    $scope.printCot = function(vFac){
        //alert(vFac.target.id);
        window.open("printCot.php?vF=" + vFac.target.id  ,"","width=500, height=600");
    }
    $scope.editFac = function(vFac){
        //alert(vFac.target.id);
        window.open("editCot.php?vF=" + vFac.target.id  ,"","width=1000, height=600");
    }

    $scope.findTel = function(event){
        var xFlag = 0;
        if(!$scope.vTel){
            xFlag = 1;
        }
        if(event.keyCode==13 && xFlag == 0){
            console.log($scope.vTel.toString().length);
            if($scope.vTel.toString().length >= 8){
                $http.post(vRutaApp +'/server/svrConsultas.php', {op:109, telcliente:$scope.vTel}).then(function(vResult){
                    if(vResult.data[0].cod == 1){
                        if(vResult.data[0].rData.length > 0) {
                            //console.log(vResult.data[0].cod);              
                            $scope.vCliente = vResult.data[0].rData[0].nombre; 
                            $scope.vRTN = vResult.data[0].rData[0].rtn;
                        }else{
                            $scope.vTel_reg = $scope.vTel;
                            $scope.vNom_cliente_reg = ""; 
                            $scope.vRtn_reg = null;

                            $("#mdl_cliente").modal();
                            //if(confirm('El cliente no se encuentra en la base, desea agregarlo?')){
                              //  console.log('Agregando Cliente');
                            //}
                        }
                    }else{
                        alert(vResult.data[0].msj);
                    }         
                });
            }else{ alert('Numero de Telefono no valido'); }
            
        }
    }

    $scope.search_cot = function(){

        var vDate1 = "";
        var vDate2 ="";

        vDate1 = $scope.vFechIni_find.getFullYear();
        vDate1 += "-" + filldate($scope.vFechIni_find.getMonth()+1);
        vDate1 += "-" + filldate($scope.vFechIni_find.getDate());

        vDate2 = $scope.vFechFin_find.getFullYear();
        vDate2 += "-" + filldate($scope.vFechFin_find.getMonth()+1);
        vDate2 += "-" + filldate($scope.vFechFin_find.getDate());



        $http.post(vRutaApp +'/server/svrConsultas.php', {op:112, tipo:$scope.vCriterioSearchF, fini:vDate1, ffin:vDate2, crit:$scope.vNumFac_find, crit2:$scope.vNomCli_find}).then(function(vResult){
            console.log(vResult.data);
            $scope.vArr_Facs_Search = vResult.data[0].rData;
            $scope.tbl_facturas = new NgTableParams({}, {dataset:$scope.vArr_Facs_Search});
    
        }, function(err){ console.log(err.data);});
    }

    function getEmpleadosVdr(){
        $http.post(vRutaApp +'/server/svrConsultas.php', {op:102, cargo:101}).then(function(vResult){
            //console.log('Getting Employees');
            if(vResult.data[0].cod == 1){                
                $scope.arrEmpleadosVdr=vResult.data[0].rData; 
            }else{
                alert('Error en Consultando DB');
            }
        }); 
    }

    $scope.change_tab = function(vIndex){
        switch(vIndex){
            case 1:
                $scope.cFacs = true;
                $scope.cConsultas = false;
            break;
            case 2:
                $scope.cFacs = false;
                $scope.cConsultas = true;
            break;
        }
    }

    $scope.save_cot = function(){
        
        //setTimeout(function(){$("#btn_save").hide();}, 10);

        var pagoFac = 0;
        var vResult = "";
        var vDate = "";

        vDate = $scope.vFecha.getFullYear();
        vDate += "-" + filldate($scope.vFecha.getMonth()+1);
        vDate += "-" + filldate($scope.vFecha.getDate());

        vDate += " " + filldate($scope.vFecha.getHours());
        vDate += ":" + filldate($scope.vFecha.getMinutes());
        vDate += ":" + filldate($scope.vFecha.getSeconds());

        //pagoFac = parseFloat($scope.arr_generales.total) - (parseFloat($scope.arr_generales.efectivo) + parseFloat($scope.arr_generales.tarjeta));
//      alert(pagoFac);
        if($scope.vFecha!="" && $scope.vCliente.length >0 && String($scope.vTel).length >0 && $scope.vRTN.length>0 ){
            calcula_fac();
            //alert($scope.arr_generales.total);
            $scope.arr_generales.cajero = 0;
            $scope.arr_generales.caja = 0;
            $scope.arr_generales.vendedor = $scope.vVendedor;
            $scope.arr_generales.fecha = vDate;

            $scope.arr_generales.cliente = $scope.vCliente;
            $scope.arr_generales.tel = $scope.vTel;
            $scope.arr_generales.rtn = $scope.vRTN;
            $scope.arr_generales.nota = $scope.vNota;

            //if($scope.arr_generales.total>0){
                $http.post(vRutaApp +'/server/svrTransacciones.php', {op:208, arrItems:$scope.arr_items, arrGenerales:$scope.arr_generales}).then(function(vResult){
                    //alert(vResult.data);
                    vResult = vResult.data.split(',');

                    if(vResult[0]==1){                        
                        window.open("printCot.php?vF=" + vResult[2]  ,"","width=500, height=600");
                        limpiar_fac();
                        $("#btn_save").show();
                    }else{
                        alert(vResult.data);
                    }
                }); 
            //}else{
              //  alert("Factura en [0]");
            //}
            
        }else{
            alert("Datos Incompletos");
        }
    }

    function validaLogin(){
        varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
        var vuser = '';
        var vpwd = '';       

        if($cookies.get(vEmpresa)){
            var obj = JSON.parse($cookies.get(vEmpresa));
            
            varSistem.user = obj.user;
            varSistem.pwd = obj.pwd;

            $http.post(vRutaApp +'/server/svrConsultas.php', {op:100, usr:varSistem.user, pwd:varSistem.pwd}).then(function(vResult){
                //alert(vResult.data);
                if(vResult.data.cod==0){
                    setTimeout(function () { window.location.replace("../../index.php");}, 500);                   
                }else{
                    
                    varSistem.id = vResult.data.id;
                    //console.log(varSistem.id);
                    $http.post(vRutaApp +'/server/svrConsultas.php', {op:108, tienda:idEmp, estado:1, cajero:varSistem.id}).then(function(vResult2){
                        //console.log(vResult2.data[0].rData[0].caja);

                        if(vResult2.length>0){
                            varSistem.caja = vResult2.data[0].rData[0].caja;
                        }
                            //alert(vResult.data);
                    }); 
                }
            });
        }       
    }

    $scope.limpiar = function(){
        limpiar_fac()
    }

    $scope.limpia_b = function(){
        limpia_busqueda();
    }

    $scope.f_addItem = function(){
        var isv =0;
        var vFlag = 0;
        if($scope.vISV){
            isv =1;
        }        

        if($scope.vCodItem.length > 0 && $scope.vDescrip.length >0 && parseInt($scope.vCantidad) > 0 && parseFloat($scope.vPrecio) >0 ){
            
            if($scope.arr_items.length == 0){
                $scope.arr_items.push({"cod": $scope.vCodItem,
                                    "desc": $scope.vDescrip,
                                    "cant": $scope.vCantidad,
                                    "isv": isv,
                                    "price": $scope.vPrecio});
            }else{
                //alert($scope.arr_items.length);
                for(i=0;i<$scope.arr_items.length;i++){
                    
                    if($scope.arr_items[i].cod == $scope.vCodItem){
                        $scope.arr_items[i].cant += $scope.vCantidad;                    
                        $scope.arr_items[i].price = $scope.vPrecio;                                            
                        $scope.arr_items[i].isv = isv;
                        vFlag = 1;
                        break;  
                    }                  
                }
                if(vFlag == 0){
                     $scope.arr_items.push({"cod": $scope.vCodItem,
                                        "desc": $scope.vDescrip,
                                        "cant": $scope.vCantidad,
                                        "isv": isv,
                                        "price": $scope.vPrecio});
                }
            }
            calcula_fac();
            limpia_addItem();
            //alert($scope.vFecha.getMonth() + '-' + $scope.vCliente);
        }else{
            alert('Datos Incompletos');
        }
    }

    function calculaPago(vT){
        var vTotalTemp = parseFloat($scope.arr_generales.total);
        if(vTotalTemp > 0){
            if(parseFloat($scope.vEfectivo)<=vTotalTemp && vT == 1){
                $scope.vTarjeta = vTotalTemp - $scope.vEfectivo;
            }
            if(parseFloat($scope.vTarjeta)<=vTotalTemp && vT == 0){
                $scope.vEfectivo = vTotalTemp - $scope.vTarjeta;
            }
        } 

        $scope.arr_generales.efectivo = $scope.vEfectivo;
        $scope.arr_generales.tarjeta = $scope.vTarjeta;
    }

    function calcula_fac(){
        var vISV=0;
        var vSubTotalExento=0;
        var vSubTotalGrabado=0;
        var vDescuento = 0;
        var vTotal = 0;

        for(i=0; i<$scope.arr_items.length;i++){
            if($scope.arr_items[i].isv == 1){
                vSubTotalGrabado += $scope.arr_items[i].cant * $scope.arr_items[i].price;            
                vISV += vSubTotalGrabado*$scope.ISV_VAL;
            }else{
                vSubTotalExento += $scope.arr_items[i].cant * $scope.arr_items[i].price; 
            }
        }
        vTotal = ((vSubTotalExento + vSubTotalGrabado) - vDescuento) + vISV;

        $scope.arr_generales.desc = 0;
        $scope.arr_generales.subTotalExento = vSubTotalExento;
        $scope.arr_generales.subTotalGrabado = vSubTotalGrabado;
        $scope.arr_generales.isv = vISV;
        $scope.arr_generales.total = vTotal;
    }

    $scope.removeItem = function(event){
	var vItem = event.target.id;
        var vArrTemp = [];
        for(i=0; i<$scope.arr_items.length; i++){
            if($scope.arr_items[i].cod != vItem){
                vArrTemp.push({"cod": $scope.arr_items[i].cod,
                                        "desc": $scope.arr_items[i].desc,
                                        "cant": $scope.arr_items[i].cant,
                                        "isv": $scope.arr_items[i].isv,
                                        "price": $scope.arr_items[i].price});
            }
        }
        $scope.arr_items = vArrTemp;
        calcula_fac();
    }

     $scope.save_client = function(){
        var vFlag = 0;
        var vError = '';

        if(!$scope.vTel_reg){
            vFlag = 1;
            vError = 'Telefono Incorrecto';
        }
        else if($scope.vTel_reg.toString().length < 8){
            vFlag = 1;
            vError = 'Telefono Incorrecto';
        }

        if(!$scope.vNom_cliente_reg){
            vFlag = 1;
            vError += '/Nombre Incorrecto';
        }
        else if($scope.vNom_cliente_reg.length < 2){
            vFlag = 1;
            vError += '/Nombre Incorrecto';
        }

        if(!$scope.vRtn_reg){
            vFlag = 1;
            vError += '/RTN Incorrecto';
        }
        else if($scope.vRtn_reg.toString().length == 0){
            vFlag = 1;
            vError += '/RTN Incorrecto';
        }

        if(vFlag==0){
            $http.post(vRutaApp +'/server/svrTransacciones.php', {op:205, tel:$scope.vTel_reg, name:$scope.vNom_cliente_reg, rtn:$scope.vRtn_reg}).then(function(vResult){
                vResult = vResult.data.split(',');
                if(vResult[0]==1){                        
                    $("#dv_sms_cliente_reg").html('Cliente Salvado Correctamente...');

                    $scope.vTel = $scope.vTel_reg;
                    $scope.vCliente = $scope.vNom_cliente_reg;
                    $scope.vRTN = $scope.vRtn_reg;

                    $scope.vTel_reg = null; 
                    $scope.vNom_cliente_reg = ""; 
                    $scope.vRtn_reg = "";
                }else{
                    alert(vResult[1]);
                }
            });             
        }else{
            $("#dv_sms_cliente_reg").html('Error:' + vError);
        }
    }

    $(document).ready(function(){
		//alert('Document Ready');
		$("#btn_menu").click(function(e) {
     		e.preventDefault();
    		$("#wrapper").toggleClass("toggled");
		});
		$("#btn_close_menu").click(function(){
    		$("#wrapper").toggleClass("toggled"); 
 		});
	});

function limpiar_fac(){
    $http.post(vRutaApp +'/server/svrConsultas.php', {op:103, tienda:idEmp, estado:1}).then(function(vResult){
        vCaja=vResult.data[0].rData[0];
        if(vCaja){            
            $scope.vCajero = vCaja.cajero;
            $scope.vCaja = vCaja.caja;
        }
    }); 

    $scope.vTel_reg = null; 
    $scope.vNom_cliente_reg = ""; 
    $scope.vRtn_reg = "";

    $scope.vFecha = "";
    $scope.vCliente = ""; 
    $scope.vTel = "";
    $scope.vRTN = "";

    $scope.vFecha = new Date();
    $scope.vCodItem = "";
    $scope.vDescrip = "";
    $scope.vCantidad = 0;
    $scope.vPrecio = 0;
    $scope.arr_items = [];    
    $scope.arr_generales = {"cliente":"", "rtn":"", "tel":"", "nota":"", "subTotalExento":0,"subTotalGrabado":0, "desc":0, "isv":0, "total":0, "fecha":"", "vendedor":"NA", "cajero":"", "caja":"", "efectivo":0, "tarjeta":0};
    $scope.vISV = false;
    $scope.vVendedor = "0";

    $scope.vEfectivo = 0;
    $scope.vTarjeta = 0;

    $scope.vNota = "";
    getEmpleadosVdr();
    
}

function limpia_busqueda(){
    $scope.vCriterioSearchF = "1";
    $scope.vFechIni_find = new Date();
    $scope.vFechFin_find = new Date();
    $scope.vNumFac_find = "";
    $scope.vNomCli_find ="";
}

function limpia_addItem(){
    $scope.vCodItem = "";
    $scope.vDescrip = "";
    $scope.vCantidad = 0;
    $scope.vPrecio = 0;
    $scope.vISV = false;
}

});
       

function getParams(param) {
    var vars = {};
    window.location.href.replace( location.hash, '' ).replace( 
        /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
        function( m, key, value ) { // callback
            vars[key] = value !== undefined ? value : '';
        }
    );

    if ( param ) {
        return vars[param] ? vars[param] : null;    
    }
    return vars;
}

function filldate(vNumber){
    var ret = "";
    if(vNumber < 10){
        ret = "0" + vNumber;
    }else{
        ret = vNumber
    }
    return ret;
}


