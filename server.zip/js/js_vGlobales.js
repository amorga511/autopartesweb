// Variable Globales

var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
//var vRutaApp = 'http://localhost/ProyectosByT/web/llantas';
var vRutaApp = 'http://yonker.empresasjireh.com';
var appTitle = 'Facturación YONKER Jireh';
var idEmp = 'YNK001';