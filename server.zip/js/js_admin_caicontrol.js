/*var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};*/


var appM = angular.module('appMain', ['ngCookies', 'ngTable']);

appM.controller('appControl1', function($scope, $http, $cookies, NgTableParams) {
    
    $scope.apptitle = appTitle;
    $scope.arrTiendas = {};
    $scope.cCai = true;
    
    if(!$cookies.get(vEmpresa)){
        console.log('no login');
        window.location.replace('../../index.php');
    }else{
        validaLogin();
    }

    limpiar_caicontrol();

    if(window.innerWidth<900){
        $scope.btn_menu = true;
    }
    
    $scope.switchMenu = function(vM){
        switch(vM){
            case 1:
                $scope.dvInicio = true;
                $scope.dvCaja = false;
                $scope.dvFacturacion = false;
                $scope.btn_menu =true;
                window.location.replace('../../main.php');
            break;
            case 2:
                window.location.replace('../../views/caja/index.php');
            break;
            case 3:
                window.location.replace('../../views/facturacion/index.php');
            break;
            case 10:
                $scope.dvInicio = false;
                $scope.dvStaff = false;
                $scope.dvPersonalOp = false;                
                window.location.reload();
            break;
            case 98:
                window.location.replace('../settings.php');
            break;
            case 99:
                console.log(vEmpresa);
                $cookies.remove(vEmpresa, {path:'/'});
                setTimeout(function(){window.location.replace('../../index.php');}, 400);

                //$http.post(vRutaApp +'/server/svrConsultas.php', {op:104}).then(function(vResult){
                  //  window.location.reload();
                //}); 
            break;
            default:
                return;
        }
        if(vM!=99){
            $("#wrapper").toggleClass("toggled");
        }
    }

    function getDatosTienda(){
        $http.post(vRutaApp +'/server/svrConsultas.php', {op:110, tienda:idEmp}).then(function(vResult){
            //console.log(vResult.data);
            if(vResult.data[0].cod == 1){                
                $scope.arrTiendas= vResult.data[0].rData;
                $scope.vRTN = vResult.data[0].rData[0].rtn;
            }else{
                alert('Error en Consultando DB');
            }

        }); 
    }

    function getCaiHist(){
        $http.post(vRutaApp +'/server/svrConsultas.php', {op:111, tienda:idEmp}).then(function(vResult){
            console.log(vResult.data);
            if(vResult.data[0].cod == 1){                
                $scope.arrCaiHist= vResult.data[0].rData;
                $scope.tbl_caihist = new NgTableParams({}, {dataset:$scope.arrCaiHist});
            }else{
                alert('Error en Consultando DB');
            }

        }); 
    }


 

    $scope.f_limpiar= function(){
        limpiar_caicontrol();
    }


    function changePageSize(newSize){
      $scope.cierresTable.count(newSize);
    }

    $scope.save_cai = function(){
        var msjR;
        var fech_limite = "";
        var vFlag = 0;

        fech_limite = $scope.vFechLimite.getFullYear();
        fech_limite += "-" + filldate($scope.vFechLimite.getMonth()+1);
        fech_limite += "-" + filldate($scope.vFechLimite.getDate());

        /*fech_limite += " " + filldate($scope.vFechLimite.getHours());
        fech_limite += ":" + filldate($scope.vFechLimite.getMinutes());
        fech_limite += ":" + filldate($scope.vFechLimite.getSeconds());*/

        if($scope.vRTN.length<12){
            vFlag =1;
        }
        if($scope.vCAI.length<13){
            vFlag =1;
        }
        if($scope.vDesde.length==0){
            vFlag =1;
        }
        if($scope.vHasta.length==0){
            vFlag =1;
        }
        if(fech_limite.length==0){
            vFlag =1;
        }



        if(vFlag==0){
            vDtosCai = {"emp":idEmp, "rtn":$scope.vRTN, "cai":$scope.vCAI, "desde":$scope.vDesde, "hasta":$scope.vHasta, "fech":fech_limite};
        

            $http.post(vRutaApp +'/server/svrTransacciones.php', {op:207, dts_cai:vDtosCai}).then(function(vResult){
                console.log(vResult.data);
                msjR = vResult.data.split(',');
                if(parseInt(msjR[0])==1){
                    alert('Datos Guardados Exitosamente');
                    limpiar_caicontrol();
                    //window.location.reload();
                } else{ 
                    alert('Error al intentar salva datos');  
                }             
            });
        }else{
            alert('Datos Inconclusos');
        }   
    }
 

    function limpiar_caicontrol(){
        $scope.vFechLimite = new Date();
        $scope.vRTN = "";
        $scope.vCAI = "";
        $scope.vDesde ="";
        $scope.vHasta ="";

        $scope.vArr_Cierres = {};

        getDatosTienda();
        getCaiHist();
    }


    
    $(document).ready(function(){
		//alert('Document Ready');
		$("#btn_menu").click(function(e) {
     		e.preventDefault();
    		$("#wrapper").toggleClass("toggled");
		});
		$("#btn_close_menu").click(function(){
    		$("#wrapper").toggleClass("toggled"); 
 		});
	});

    function validaLogin(){
        varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
        var vuser = '';
        var vpwd = '';       

        if($cookies.get(vEmpresa)){
            var obj = JSON.parse($cookies.get(vEmpresa));
            
            varSistem.user = obj.user;
            varSistem.pwd = obj.pwd;
            //console.log(varSistem.pwd); 

            $http.post(vRutaApp +'/server/svrConsultas.php', {op:100, usr:varSistem.user, pwd:varSistem.pwd}).then(function(vResult){
                //alert(vResult.data.cod);
                if(vResult.data.cod==0){
                    setTimeout(function () { window.location.replace("../../index.php");}, 500);                   
                }else{
                    varSistem.id = vResult.data.id;
                    //console.log(varSistem.id);
                    $http.post(vRutaApp +'/server/svrConsultas.php', {op:108, tienda:idEmp, estado:1, cajero:varSistem.id}).then(function(vResult2){
                        //alert(vResult2.data[0].rData[0].caja);
                        varSistem.caja = vResult2.data[0].rData[0].caja;
                            //alert(vResult.data);
                    }); 
                }
            });
        }       
    } 
});
       

function getParams(param) {
    var vars = {};
    window.location.href.replace( location.hash, '' ).replace( 
        /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
        function( m, key, value ) { // callback
            vars[key] = value !== undefined ? value : '';
        }
    );

    if ( param ) {
        return vars[param] ? vars[param] : null;    
    }
    return vars;
}

function filldate(vNumber){
    var ret = "";
    if(vNumber < 10){
        ret = "0" + vNumber;
    }else{
        ret = vNumber
    }
    return ret;
}