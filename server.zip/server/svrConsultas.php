<?php session_start(); 

	$postdata = file_get_contents("php://input");
	$vPost = json_decode($postdata);

switch((int)$vPost->op) {
	case 100:
		validaLogin($vPost->usr, $vPost->pwd);
		break;
	case 101:
		getTiendas();
		break;
	case 102:
		getEmpleados($vPost->cargo);
		break;
	case 103:
		getCajas($vPost->tienda, $vPost->estado);
		break;
	case 104:
		closeSession();
		break;
	case 105:
		detalleFac($vPost->tienda, $vPost->caja);
		break;
	case 106:
		getFacturas($vPost->tipo, $vPost->fini, $vPost->ffin, $vPost->crit, $vPost->crit2);
		break;
	case 107:
		getCierresCaja();
		break;
	case 108:
		getCajas2($vPost->tienda, $vPost->estado, $vPost->cajero);
		break;
	case 109:
		getClient($vPost->telcliente);
		break;
	case 110:
		getDatosTienda($vPost->tienda);
		break;
	case 111:
		getCaiHist($vPost->tienda);		
		break;
	case 112:
		getCotizaciones($vPost->tipo, $vPost->fini, $vPost->ffin, $vPost->crit, $vPost->crit2);
		break;
}

//Funcion para validar credenciales de usuario
function validaLogin($vUser, $vPwd){	
	include 'dblink.php';
	$arrTemp =array();

	$vQuery = "SELECT * FROM usuarios where estado= 1 and usuario='" . $vUser . "'";
		$arrResult = array();
		if(strlen($vPwd)>0){
		if($result = $con->query($vQuery)){
			$rows = $result->fetch_array();
			if($rows[2]==$vPwd){
				$arrTemp = array("cod"=>1, "msj"=>"Success", "id"=>$rows[3]);
				$_SESSION["login"] = 1;
			}else{
				$arrTemp = array("cod"=>99, "msj"=>'Error de Usuario');
			}
		}else{
			$arrTemp = array("cod"=>99, "msj"=>$con->error);
		}
	}else{ $arrTemp = array("cod"=>99, "msj"=>'Error de Usuario'); } 

	echo json_encode($arrTemp);
}

//Funcion para obtener tiendas disponibles
function getTiendas(){	
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_tiendas where status= 1";
	array_push($arrTemp, array("id"=>0,"name"=>"-"));
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("id"=>$rows[0], "name"=>$rows[1]));			
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}
	//print_r($arrFinal);
	echo json_encode($arrFinal); 
}

function getEmpleados($vTipo){	
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_personal where status_persona= 1 and cargo_persona=" . $vTipo;
	array_push($arrTemp, array("id"=>0,"name"=>"-"));
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("id"=>$rows[0], "name"=>$rows[1]));			
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}
	echo json_encode($arrFinal); 
}

function getCajas($vTienda, $Open){	
	include 'dblink.php';
	$arrTemp =array();
	$arrFinal = array();

	if((int)$Open == 0){
		$vQuery = "SELECT * FROM tbl_cajas where status= 1 and tienda='" . $vTienda . "' and estado_caja=0";
		array_push($arrTemp, array("id"=>0,"name"=>"-"));
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp, array("id"=>$rows[1], "name"=>$rows[1]));			
			}
			array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}
	}else{
		$vQuery = "SELECT tienda, cajero, num_caja, monto, fech_apertura FROM tbl_cajas where status= 1 and tienda='" . $vTienda . "' and estado_caja=1";
		
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp, array("tienda"=>$rows[0], "cajero"=>$rows[1],
										"caja"=>$rows[2],"monto"=>$rows[3],"f_open"=>$rows[4]));			
			}
			array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}
	}	
	echo json_encode($arrFinal); 
}


function getCajas2($vTienda, $Open, $id){	
	include 'dblink.php';
	$arrTemp =array();
	$arrFinal = array();

	if((int)$Open == 0){
		$vQuery = "SELECT * FROM tbl_cajas where status= 1 and tienda='" . $vTienda . "' and estado_caja=0 and cajero='" . $id . "'";
		array_push($arrTemp, array("id"=>0,"name"=>"-"));
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp, array("id"=>$rows[1], "name"=>$rows[1]));			
			}
			array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}
	}else{
		$vQuery = "SELECT tienda, cajero, num_caja, monto, fech_apertura FROM tbl_cajas where status = 1 and tienda='" . $vTienda . "' and estado_caja=1 and cajero='" . $id . "'";
		
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp, array("tienda"=>$rows[0], "cajero"=>$rows[1],
										"caja"=>$rows[2],"monto"=>$rows[3],"f_open"=>$rows[4]));			
			}
			array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}
	}	
	//print_r($arrFinal);
	echo json_encode($arrFinal); 
}

function closeSession(){	
	$_SESSION["login"] = 0;
}

function detalleFac($vTienda, $vCaja){
	include 'dblink.php';
	$vFopen = "";
	$vMonto = 0;
	$vDevs = 0;
	$vGastos = 0;

	$vUtilidad = 0;
	$vCajero = "";
	$arrTemp = array("detalle"=>array(),"cierre"=>array(), "trans"=>array());
	$arrFinal =  array();

	$vQuery = "SELECT tienda, cajero, num_caja, monto, fech_apertura FROM tbl_cajas where estado_caja=1 and tienda='" . $vTienda . "' and num_caja=". $vCaja;
	//echo $vQuery;
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			$vMonto = $rows[3];
			$vCajero = $rows[1];
			$vFopen = $rows[4];		
		}
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}

	$vQuery = "SELECT id, fech_fac, efectivo, tarjeta, total FROM tbl_facturas where estado=1 and caja= ". $vCaja ." and fech_fac between '" . $vFopen . "' and now()";
		
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp["detalle"], array("factura"=>$rows[0], "fecha"=>$rows[1],
										"efectivo"=>$rows[2],"tarjeta"=>$rows[3],"total"=>$rows[4], "cajero"=>$vCajero));
				$vUtilidad += (float)$rows[4];		
			}
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}

	$vQuery = "SELECT id, fecha, tipo_tran, cajero, caja, monto, detalle FROM tbl_trans_caja where caja= ". $vCaja ." and cajero='" . $vCajero . "' and fecha between '" . $vFopen . "' and now()";
		
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp["trans"], array("fecha"=>$rows[1],
										"tipo"=>$rows[2],"monto"=>$rows[5], "detalle"=>$rows[6]));
				if((int)$rows[2]==1){
					$vDevs += (float)$rows[5];
				}else if((int)$rows[2]==2){
					$vGastos += (float)$rows[5];
				}		
			}
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}

		array_push($arrTemp["cierre"], array("caja"=>$vCaja, "cajero"=>$vCajero,"fopen"=>$vFopen,"saldo_ini"=>$vMonto, "saldo_fin"=>$vUtilidad, "devs"=>$vDevs, "gastos"=>$vGastos));

		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	//print_r($arrFinal);
	echo json_encode($arrFinal); 

}

function getFacturas($vTipoB, $vFIni, $vFFin, $vCrit, $vCrit2){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	if((int)$vTipoB==1){
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_facturas where estado=1 and fech_fac between '" . $vFIni . " 00:00:00' and '". $vFFin ." 23:59:59'";
	}else if((int)$vTipoB==3){
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_facturas where  upper(cliente) LIKE '%" . strtoupper($vCrit2) . "%'";
	}
	else{
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_facturas where  id='" . $vCrit . "'";
	}
	
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("factura"=>$rows[0], "fecha"=>$rows[1],"cliente"=>$rows[2],"total"=>$rows[3]) );			
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}
	echo json_encode($arrFinal); 
}

function getCierresCaja(){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_cajas_cierre";
	//echo $vQuery;
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("num"=>intval($rows["id"]), "caja"=>$rows["caja"],"cajero"=>$rows["cajero"],"fopen"=>$rows["fech_open"],"fclose"=>$rows["fech_close"]));	
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}	
	echo json_encode($arrFinal); 
}

function getClient($vTelClient){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_clientes where telefono=" . $vTelClient;
	if( strlen($vTelClient) > 0){
		if($result = $con->query($vQuery)){
			while($rows = $result->fetch_array())
			{
				array_push($arrTemp, array("telefono"=>$rows["telefono"], "rtn"=>$rows["rtn"],"nombre"=>$rows["nombre_cliente"]));	
			}
			array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
		}else{
			array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
		}	
	}else{
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}
	echo json_encode($arrFinal); 
}

function getDatosTienda($vTienda){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_tiendas where status = 1 and id='" . $vTienda . "'";
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("id"=>intval($rows["id"]), "nombre"=>$rows["nombre_tienda"],"dir"=>$rows["direccion_tienda"],"telefono"=>$rows["telefono_tienda"],"email"=>$rows["email"], "rtn"=>$rows["rtn_tienda"]));	
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}	
	echo json_encode($arrFinal); 

}

function getCaiHist($vTienda){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	$vQuery = "SELECT * FROM tbl_cai_control where empresa='" . $vTienda . "' order by estado desc";
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			if($rows["estado"]==0){
				$vEstado = 'Inactivo';
			}else{
				$vEstado = 'Activo';
			}
			array_push($arrTemp, array("rtn"=>$rows["rtn"], "cai"=>$rows["cai"],"fechalimite"=>$rows["fecha_limite"],"desde"=>$rows["rango_desde"],"hasta"=>$rows["rango_hasta"], "estado"=>$vEstado));	
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}	
	echo json_encode($arrFinal); 

}


function getCotizaciones($vTipoB, $vFIni, $vFFin, $vCrit, $vCrit2){
	include 'dblink.php';
	$arrTemp = array();
	$arrFinal = array();

	if((int)$vTipoB==1){
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_cotizaciones where estado=1 and fech_fac between '" . $vFIni . " 00:00:00' and '". $vFFin ." 23:59:59'";
	}else if((int)$vTipoB==3){
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_cotizaciones where  upper(cliente) LIKE '%" . strtoupper($vCrit2) . "%'";
	}
	else{
		$vQuery = "SELECT id, fech_fac, cliente, total FROM tbl_cotizaciones where  id='" . $vCrit . "'";
	}
	
	if($result = $con->query($vQuery)){
		while($rows = $result->fetch_array())
		{
			array_push($arrTemp, array("factura"=>$rows[0], "fecha"=>$rows[1],"cliente"=>$rows[2],"total"=>$rows[3]) );			
		}
		array_push($arrFinal, array("cod"=>1, "msj"=>"Success", "rData"=>$arrTemp));
	}else{
		array_push($arrFinal, array("cod"=>99, "msj"=>$con->error));
	}
	echo json_encode($arrFinal); 
}

?>










