<?php 

/*
	$server = "mysql.hostinger.mx";
	$user = "u912818170_ropa";
	$pwd = "Jireh.18";
	$db = "u912818170_ropa";*/
	
	
	$server = "localhost";
	$user = "root";
	$pwd = "yonker";
	$db = "u912818170_llant";

	$con = new mysqli($server, $user, $pwd, $db);
	if($con->connect_error)
	{
		echo $con->connect_error();
	}
?>