<?php session_start(); ?>
<!DOCTYPE html>
<html ng-app="appMain">
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="../../css/bootstrap.min.css" />
<link rel="stylesheet" href="../../css/css_main.css" />
<link rel="stylesheet" href="../../css/simple-sidebar.css" />
<?php
    /*if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: ../../index.php");
        }
    }else{
        header("Location: ../../index.php");
    }*/
?>
</head>
<body ng-controller="appControl1">

<div id="wrapper">
    <?php include '../menu.php'; ?>

    <div id="page-content-wrapper" style="padding:0px">
        <!-- Div Contenido -->
        <div class="container-fluid" style="padding:0px;">
        	<!-- Barra Superior -->
            <?php include '../topbar.php'; ?>

            <!-- SubDiv Contenido -->
            <div class="container-fluid c_anime_div" style="padding:20px; padding-top:60px;">
                <ul class="nav nav-tabs">
                    <li ng-class="{'active':cCai}" ng-click="change_tab(1)">
                        <a href="#">Cai Control</a>
                    </li>
                </ul>

                 <!-- Seccion Facturas -->
                <div class="col-xs-12" style="background-color:#FFFFFF" ng-show="cCai">
                    <br />
                    <h3>Registo Nuevo CAI Facturación</h3>
                    <br />
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-6"><span>RTN</span>
                            <input type="text" class="form-control" id="txtRtn" ng-model="vRTN" readonly="" />
                        </div>  
                    </div>
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-6"><span>CAI</span>
                            <input type="text" class="form-control" id="txtCai" ng-model="vCAI" />
                        </div>  
                    </div>
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-3"><span>Rango Desde</span>
                            <input type="text" class="form-control" id="txtDesd" ng-model="vDesde"/>
                        </div> 
                        <div class="col-md-3"><span>Rango Hasta</span>
                            <input type="text" class="form-control" ng-model="vHasta"/>
                        </div>   
                    </div>
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-3"><span>Fecha Limite de Emisión</span>
                            <input type="date" class="form-control" id="txtFechlimite" ng-model="vFechLimite"/>
                        </div>    
                    </div>
                    <div style="text-align: right; margin-top: 10px">
                    <input type="button" style="margin-top:15px" class="btn btn-info" value="Salvar" ng-click="save_cai()">
                    <input type="button" style="margin-top:15px" class="btn btn-default" value="Limpiar" ng-click="f_limpiar()">
                    </div>
                    <br />
                    <hr />

                    <br />
                    <h3>Historial CAIs</h3>
                    <br /><br />
                    <table ng-table="tbl_caihist" class="table table-bordered table-striped">
                        <!--<thead>
                            <tr>
                                <th>NumFac</th>
                                <th>Fecha</th>
                                <th>Cliente</th>
                                <th>Monto</th>
                                <th></th>
                            </tr>
                        </thead>-->
                        <tbody>
                            <tr ng-repeat="vCai in $data">
                                <td title="'RTN'" sortable="'rtn'">{{vCai.rtn}}</td>
                                <td title="'CAI'" sortable="'cai'">{{vCai.cai}}</td>
                                <td title="'Desde'" >{{vCai.desde}}</td>
                                <td title="'Hasta'">{{vCai.hasta}}</td>
                                <td title="'FechLimite'" align="center">{{vCai.fechalimite}}</td>
                                <td title="'Estado'" align="center" sortable="'estado'">{{vCai.estado}}</td>
                            </tr>
                        </tbody>
                    </table>
                <br />            
                <hr />
                </div><!-- Fin Facturacion -->
                
            </div>
            <!-- Fin SubDiv Contenido -->
            
        </div><!-- Fin Dvi Contenido -->      
    </div>

</div>
</body>

<script type="text/javascript" src="../../js/jquery-3.1.1.min.js"></script>
<!--<script type="text/javascript" src="cordova.js"></script>-->
<script type="text/javascript" src="../../js/bootstrap.min.js"></script>


<script src="../../js/angular.min.js"></script>
<script src="../../js/ngCookies.min.js"></script>
<script src="../../js/js_vGlobales.js"></script>
<script type="text/javascript" src="../../js/js_admin_caicontrol.js"></script>

<link rel="stylesheet"; href="https://unpkg.com/ng-table@2.0.2/bundles/ng-table.min.css">
<script src="https://unpkg.com/ng-table@2.0.2/bundles/ng-table.min.js"></script>

</html>
