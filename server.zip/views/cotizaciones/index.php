<?php session_start(); ?>
<!DOCTYPE html>
<html ng-app="appMain">
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">

<link rel="stylesheet" href="../../css/bootstrap.min.css" />
<link rel="stylesheet" href="../../css/css_main.css" />
<link rel="stylesheet" href="../../css/simple-sidebar.css" />
<?php
    /*if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: ../../index.php");
        }
    }else{
        header("Location: ../../index.php");
    }*/
?>
</head>
<body ng-controller="appControl1">

<div id="wrapper">
    <?php include '../menu.php'; ?>

    <div id="page-content-wrapper" style="padding:0px">
        <!-- Div Contenido -->
        <div class="container-fluid" style="padding:0px;">
        	<!-- Barra Superior -->
            <?php include '../topbar.php'; ?>

            <!-- SubDiv Contenido -->
            <div class="container-fluid c_anime_div" style="padding:20px; padding-top:60px;">
                <ul class="nav nav-tabs">
                    <li ng-class="{'active':cFacs}" ng-click="change_tab(1)">
                        <a href="#">Cotizaciones</a>
                    </li>
                    <li ng-class="{'active':cConsultas}" ng-click="change_tab(2)">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Consultas Cotizaciones</a>
                    </li>
                </ul>

                 <!-- Seccion Facturas -->
                <div class="col-xs-12" style="background-color:#FFFFFF" ng-show="cFacs">
                    <br />
                    <h3>Cotización </h3>
                    <br />
                    <div class="row"> 
                        <div class="col-md-3"><span>Fecha</span><input type="date" class="form-control" ng-model="vFecha" /></div>                   
                        <div class="col-md-3"><span>Vendedor</span>
                            <select class="form-control" ng-model="vVendedor">
                                 <option value="{{ row2.id }}" ng-repeat="row2 in arrEmpleadosVdr">{{ row2.name }}</option>
                            </select>
                        </div>
                        <!--<div class="col-md-3"><span>Cajero</span><input type="text" class="form-control" ng-model="vCajero" readonly /></div>
                        <div class="col-md-2"><span>Caja</span><input type="text" class="form-control" ng-model="vCaja" readonly /></div>
                        -->
                    </div>

                    <div class="row" style="margin-top:8px">
                        <div class="col-md-3">
                            <span>Telefono</span>
                            <input type="number" ng-keypress="findTel($event)" class="form-control" placeholder="Telefono" ng-model="vTel" />
                        </div> 
                        <div class="col-md-3">
                            <span>Cliente</span>
                            <input type="text" class="form-control" placeholder="Cliente" ng-model="vCliente" />
                        </div>
                        <div class="col-md-3">
                            <span>RTN</span>
                            <input type="text" class="form-control" placeholder="RTN" ng-model="vRTN" />
                        </div>                                            
                    </div>
                    <hr />
                    <div class="row">
                        <div class="col-md-2" style="padding-right:3px">
                            <span>Cod Item.</span>
                            <input type="text"  ng-model="vCodItem" placeholder="Cod Item" class="form-control"/>
                        </div>
                        <div class="col-md-4 input_fac">
                            <span>Descripcion</span>
                            <input type="text" ng-model="vDescrip" placeholder="Descripcion" class="form-control" />
                        </div>
                        <div class="col-md-2 input_fac">
                            <span>Cantidad</span>
                            <input type="number" ng-model="vCantidad" placeholder="0" class="form-control" />
                        </div>
                        <div class="col-md-2 input_fac">
                            <span>Precio</span>
                            <input type="number" ng-model="vPrecio" placeholder="L" class="form-control" />                            
                        </div>
                        <div class="col-md-1 input_fac" style="padding-left:10px">
                            <span>ISV</span><br />
                            <input type="checkbox" ng-model="vISV" style="margin-left:10px"></label>
                        </div>
                        <div class="col-md-1 input_fac" style="padding:0px">
                            <input type="button" value="Add" class="btn btn-info" ng-click="f_addItem()" style="margin-top:20px; width:50px" />
                        </div>
                    </div>
                    <br />
                    <div class="panel panel-info" style="border:2px">
                    <div class="panel panel-heading" style="margin:0px">
                        <label>Detalle</label>
                    </div>
                    <div class="panel panel-body" style="padding-top: 0px">
                        <table class="table table-striped">
                            <thead>
                                <th>CodItem</th>
                                <th>Descripcion</th>
                                <th>Cantidad</th>
                                <th>ISV</th>
                                <th>Precio</th>
				<th></th>
                            </thead>
                            <tbody>
                                <tr ng-repeat="rItems in arr_items">
                                    <td>{{ rItems.cod }}</td>
                                    <td>{{ rItems.desc }}</td>
                                    <td>{{ rItems.cant }}</td>
                                    <td>{{ rItems.isv }}</td>
                                    <td>{{ rItems.price }}</td>
				    <td><span class="glyphicon glyphicon-remove remove_cta" id="{{rItems.cod}}" ng-click="removeItem($event)"></span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    </div>
                    <div class="row"><div class="col-md-6"></div>
                        <div class="col-md-4"><span>SubTotal Exento</span><span style="float: right;">L.</span></div>
                        <div class="col-md-2" style="text-align: right; padding-right:40px"><span>{{ arr_generales.subTotalExento }}</span></div>
                    </div>
                    <div class="row"><div class="col-md-6"></div>
                        <div class="col-md-4"><span>SubTotal Grabado</span><span style="float: right;">L.</span></div>
                        <div class="col-md-2" style="text-align: right; padding-right:40px"><span>{{ arr_generales.subTotalGrabado }}</span></div>
                    </div>
                    <div class="row"><div class="col-md-6"></div>
                        <div class="col-md-4"><span>Descuento</span><span style="float: right;">L.</span></div>
                        <div class="col-md-2" style="text-align: right; padding-right:40px"><span>0</span></div>
                    </div>
                    <div class="row"><div class="col-md-6"></div>
                        <div class="col-md-4"><span>ISV</span><span style="float: right;">L.</span></div>
                        <div class="col-md-2" style="text-align: right; padding-right:40px"><span>{{ arr_generales.isv }}</span></div>
                    </div>
                    <div class="row"><div class="col-md-6"></div>
                        <div class="col-md-4"><b><span>TOTAL</span><span style="float: right;">L.</span></b></div>
                        <div class="col-md-2" style="text-align: right; padding-right:40px"><b><span>{{ arr_generales.total }}</span></b></div>
                    </div>
                    <br />
                    <div class="row"><div class="col-md-6"><span>Nota:</span><textarea class="form-control" ng-model="vNota"></textarea></div></div>
                    <br />

                    <!--<b><span>Pago</span></b><br />
                    <div class="row" style="margin-top: 5px">
                        <div class="col-md-3"><span>Efectivo</span>
                            <input type="numer" class="form-control"  placeholder="L." ng-model="vEfectivo" ng-blur="calcPago(1)"></input>
                        </div>
                        <div class="col-md-3"><span>Tarjeta</span>
                            <input type="number" class="form-control" placeholder="L." ng-model="vTarjeta" ng-blur="calcPago(0)"></input>
                        </div>
                    </div>-->
                    <br />
                    <input type="button" id="btn_save" value="Save" class="btn btn-success" ng-click="save_cot()" />
                    <input type="button" id="btn_clear" value="Clear" class="btn btn-default" ng-click="limpiar()" />
                    

                    <br /><br />
                </div><!-- Fin Facturacion -->

                <!-- Seccion Facturas -->
                <div class="col-xs-12" style="background-color:#FFFFFF" ng-show="cConsultas">
                    <br />
                    <h3>Busqueda Cotizacion </h3>
                    <br />
                    <div class="row">
                        <div class="col-md-3"><span>Criterio</span>
                            <select class="form-control" ng-model="vCriterioSearchF">
                                <option value="1">Por Fechas</option>
                                <option value="2">Por Num. Factura</option>
                                <option value="3">Por Cliente</option>
                            </select>
                        </div>   
                    </div>
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-3"><span>Fecha Inicio</span>
                            <input type="date" class="form-control" ng-model="vFechIni_find" />
                        </div> 
                        <div class="col-md-3"><span>Fecha Fin</span>
                            <input type="date" class="form-control" ng-model="vFechFin_find"/>
                        </div>   
                    </div>

                    <div class="row" style="margin-top:5px">
                        <div class="col-md-3"><span>Num Factura</span>
                            <input type="text" class="form-control" ng-model="vNumFac_find"/>
                        </div>  
                    </div>
                    <div class="row" style="margin-top:5px">
                        <div class="col-md-3"><span>Nombre Cliente</span>
                            <input type="text" class="form-control" ng-model="vNomCli_find"/>
                        </div>  
                    </div>
                    <input type="button" style="margin-top:15px" class="btn btn-info" value="Buscar" ng-click="search_cot()">
                    <input type="button" style="margin-top:15px" class="btn btn-default" value="Limpiar" ng-click="limpia_b()">
                    <br /><br />
                    <table ng-table="tbl_facturas" class="table table-bordered table-striped">
                        <!--<thead>
                            <tr>
                                <th>NumFac</th>
                                <th>Fecha</th>
                                <th>Cliente</th>
                                <th>Monto</th>
                                <th></th>
                            </tr>
                        </thead>-->
                        <tbody>
                            <tr ng-repeat="vFacs in $data">
                                <td title="'NumFac'" sortable="'factura'">{{vFacs.factura}}</td>
                                <td title="'Fecha'" sortable="'fecha'">{{vFacs.fecha}}</td>
                                <td title="'Cliente'" >{{vFacs.cliente}}</td>
                                <td title="'Monto'" sortable="'total'" align="right">{{vFacs.total}}</td>
                                <td title="'Edit'" align="center"><input type="button" value="-" class="btn btn-link" id="{{vFacs.factura}}"</td>
                                <td title="'Print'" align="center"><input type="button" value="Print" class="btn btn-link" id="{{vFacs.factura}}" ng-click="printCot($event)"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Fin SubDiv Contenido -->
            <div id="mdl_cliente" class="modal fade" role="dialog" data-backdrop="static">
            <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Registro Nuevo Cliente</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <span>Telefono Cliente</span>
                            <input type="number" class="form-control" placeholder="Telefono" ng-model="vTel_reg" />
                        </div>
                        </div>
                        <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <span>Nombre Cliente</span>
                            <input type="text" class="form-control"  placeholder="Nombre" ng-model="vNom_cliente_reg" />
                        </div>
                        </div>
                        <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <span>RTN Cliente</span>
                            <input type="text" class="form-control"  placeholder="RTN" ng-model="vRtn_reg" />
                        </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div style="float: left;" id="dv_sms_cliente_reg"></div>
                        <button type="button" class="btn btn-success" ng-click="save_client()">Guardar</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
            </div>
        </div><!-- Fin Dvi Contenido -->      
    </div>

</div>
</body>

<script type="text/javascript" src="../../js/jquery-3.1.1.min.js"></script>
<!--<script type="text/javascript" src="cordova.js"></script>-->
<script type="text/javascript" src="../../js/bootstrap.min.js"></script>


<script src="../../js/angular.min.js"></script>
<script src="../../js/ngCookies.min.js"></script>
<script src="../../js/js_vGlobales.js"></script>
<script type="text/javascript" src="../../js/js_cotizaciones.js"></script>

<link rel="stylesheet"; href="https://unpkg.com/ng-table@2.0.2/bundles/ng-table.min.css">
<script src="https://unpkg.com/ng-table@2.0.2/bundles/ng-table.min.js"></script>

</html>
