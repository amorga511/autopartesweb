﻿<?php session_start(); ?>
<!DOCTYPE html>
<html ng-app="appMain">
<head>
<title></title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">

<?php

    /*if(isset($_SESSION["login"])){
        if($_SESSION["login"]==0){
            header("Location: ../../index.php");
        }
    }else{
        header("Location: ../../index.php");
    }*/

    if($_SESSION["login"]==0){
        $x=null;
    }else{
        $numCierre = $_GET["vC"];

        $vFacturas = array();
        $vTranscaja = array();
        $vCantLetras = "0/100";
        $vVtasVendedores = array();

        $rtn = "";
        $empresa = "";
        $eDir = "";
        $eTel = "";
        $eEmail = "";

        $vCaja ="";
        $vCajero = "";

        $vTotalFacs = 0;
        $vEfectivo = 0;
        $vTarjeta = 0;
        $vDevs = 0;
        $vGastos = 0;
        
        $fechDesd="";
        $fechHasta="";
        $vTipoTran = '';

        include '../../server/dblink.php';

        $vQuery = "SELECT * FROM tbl_cajas_cierre where id=" .  $numCierre;
        if($res1 = $con->query($vQuery)){
            while($rows = $res1->fetch_assoc()){
                $vCaja = $rows["caja"];
                $vCajero = $rows["cajero"];
                $fechDesd = $rows["fech_open"];
                $fechHasta = $rows["fech_close"];
                $vDevs = $rows["devoluciones"];
                $vGastos = $rows["egresos"];
                //$vTotalFacs = $rows["ingresos_fac"];
                $vSaldo_ini = $rows["saldo_inicial"];
                $vUtilNeta = $rows["utilidad_neta"];
            }
        }else{
            echo $con->error;
        }
        
        $vQuery = "SELECT * FROM tbl_facturas where estado=1 and fech_fac between '" . $fechDesd . "' and '" . $fechHasta . "' and caja=" . $vCaja . " and cajero='" . $vCajero . "'";
        if($res2 = $con->query($vQuery)){
            while($row2 = $res2->fetch_assoc()) {
                array_push($vFacturas, array("numfac"=>$row2["id"],"efectivo"=>$row2["efectivo"], "tarjeta"=>$row2["tarjeta"], "total"=>$row2["total"]));
                $vEfectivo += (float)$row2["efectivo"];
                $vTarjeta += (float)$row2["tarjeta"];
                $vTotalFacs += (float)$row2["total"];
            }
        }

        $vQuery = "SELECT * FROM tbl_trans_caja where status=1 and fecha between '" . $fechDesd . "' and '" . $fechHasta . "' and caja=" . $vCaja . " and cajero='" . $vCajero . "'";

        if($res2 = $con->query($vQuery)){
            while($row2 = $res2->fetch_assoc()) {
                if($row2["tipo_tran"] == 1){
                    $vTipoTran = 1;
                }elseif($row2["tipo_tran"] == 2){
                    $vTipoTran = 2;
                }
                else{
                    $vTipoTran = 'NA';
                }
                array_push($vTranscaja, array("tipo"=>$vTipoTran,"detalle"=>$row2["detalle"], "fecha"=>$row2["fecha"], "monto"=>$row2["monto"]));
            }
        }

        $vSQL = "SELECT * FROM tbl_tiendas";
        if($resC = $con->query($vSQL)){
            while($rowC = $resC->fetch_array()){
                //$cai = $rowC[3];
                $rtn = $rowC[5];
                $empresa = $rowC[1];
                $eDir = $rowC[2];
                $eTel = $rowC[3];
                $eEmail = $rowC[4];
            }
        }


        // Resumen de Ventas y Devoluciones por Vendedores.
        $vSQL =  "SELECT b.nombre_persona,";
        $vSQL .= "      b.apellido_persona,";
        $vSQL .= "      c.devs,";
        $vSQL .= "      sum(total) as tot_facs ";
        $vSQL .= "FROM    tbl_facturas a ";
        $vSQL .= "      left join tbl_personal b on (a.vendedor=b.id) ";
        $vSQL .= "      left join (select id_vendedor, sum(monto) as devs from tbl_trans_caja ";
        $vSQL .= "      where   fecha between '". $fechDesd ."' and '". $fechHasta ."' ";
        $vSQL .= "      and tipo_tran = 1 ";
        $vSQL .= "group by id_vendedor) c on (a.vendedor=c.id_vendedor) ";
        $vSQL .= "      where   a.fech_fac between '". $fechDesd ."' and '". $fechHasta ."' ";
        $vSQL .= "      group by b.nombre_persona, ";
        $vSQL .= "               b.apellido_persona,";
        $vSQL .= "               c.devs";

        if($res2 = $con->query($vSQL)){
            while($row2 = $res2->fetch_array()) {
                array_push($vVtasVendedores, array("vendedor"=>$row2[0] . ' ' . $row2[1], "devs"=>$row2[2], "facs"=>$row2[3]));
            }
        }

    }
?>

<style>
#dvBody{
    padding:20px;
    width:850px;
    margin:0 auto;
    /*background-color: gary;*/
}
.font1{
    font-family: 'Time New Roman';
    font-size:18px;
    line-height: 1.3;
    padding-left: 2px;
    padding-right: 2px;
    font-weight: bold;
}

.font2{
    line-height: 1.3;
    font-family: 'Time New Roman';
    font-size: 16px;
    padding-left: 2px;
    padding-right: 2px;
    font-weight: bold;
}

.font3{
    line-height: 1.3;
    font-family: 'Time New Roman';
    font-size: 16px;
    text-align: middle;    
    padding: 2px;
    /*border:solid 1px;*/
}

.grid{
    border:solid 1px gray;
    border-collapse: collapse;
}

.bg{
    background-color:#D8D8D8;
    color:black;
}

.row {
    width: 100%;
    float: left;
}

.col-6{
    width: 50%;
    float: left;
}

.col-2{
    width: 16.66%;
    float: left;
}

}
</style>
</head>
<body ng-controller="appControl1">

<div id="dvBody">
    <br />

    <div class="row" style="margin-bottom:30px;">
        <center>
        <div class="col-6"><img src="../../img/logo.png" width="200px" height="110px" style="margin-bottom:10px" /></div>
        <div class="col-6">
            <div class="row font1"><?= $empresa; ?></div></b>
            <div class="row font2" >RTN: <?= $rtn; ?></div>
            <div class="row font2"><?= $eDir; ?></div>
            <div class="row font2">Tel: <?= $eTel; ?></div>
            <div class="row font2">E-mail: <?= $eEmail; ?></div>
        </div>
        </center>
    </div>
    <br>
    <center><h3>Cierre de Caja</h3></center>
    <div style="padding:1%; width:98%; float:left; margin-bottom:25px; border:solid 1px gray">
        <table>
            <tr>
                <td width="150px">Cierre Numero:</td>
                <td width="150px"><?= $numCierre ?></td>
                <td width="150px">Caja:</td>
                <td width="150px"><?= $vCaja ?></td>
            </tr>
            <tr>
                <td width="150px">Cajero</td>
                <td width="150px"><?= $vCajero ?></td>
                <td width="150px">Fecha Open:</td>
                <td width="150px"><?= $fechDesd ?></td>
            </tr>
            <tr>
                <td width="150px"></td>
                <td width="150px"></td>
                <td width="150px">Fecha Close:</td>
                <td width="150px"><?= $fechHasta ?></td>
            </tr>
        </table>
    </div>
    <br/>
    <table width="100%" cellspacing="0" cellpadding="3" border="1">
        <tr><td><b>Monto Apertura</b></td><td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vSaldo_ini,2) ?></b></td></tr>
    </table>
    <br />

    <table width="100%" cellspacing="0" cellpadding="3" border="1">
        <tr style="background-color:#D8D8D8; color:black">
            <th>Factura</th>
            <th>Efectivo</th>
            <th>Tarjeta</th>
            <th>Total</th>
        </tr>
<?php
    for($i=0;$i<count($vFacturas); $i++){
    echo "<tr>
            <td align=\"left\">" . $vFacturas[$i]["numfac"] ."</td>
            <td align=\"right\"><label style=\"float:left\">L.</label>". $vFacturas[$i]["efectivo"] ."</td>
            <td align=\"right\"><label style=\"float:left\">L.</label>". $vFacturas[$i]["tarjeta"] ."</td>
            <td align=\"right\"><label style=\"float:left\">L.</label>". $vFacturas[$i]["total"] ."</td>
        </tr>";
    }
?>  
    <tr bgcolor="#F2F2F2">
        <td><center><b>Totales</b></center></td>        
        <td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vEfectivo, 2) ?></b></td>
        <td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vTarjeta,2) ?></b></td>        
        <td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vTotalFacs,2) ?></b></td>
    </tr>
    </table>

    <br />

    <table width="100%" cellspacing="0" cellpadding="3" border="1">
        <tr><td colspan="3"><label>Dev/Venta</label></td></tr>
        <tr style="background-color:#D8D8D8; color:black">
            <th width="42%">Detalle</th>
            <th>Fecha</th>
            <th>Monto</th>
        </tr>
<?php
    $tot_devs = 0;
    for($i=0;$i<count($vTranscaja); $i++){
        if((int)$vTranscaja[$i]["tipo"]==1){
            echo "<tr>
                    <td align=\"left\">" . $vTranscaja[$i]["detalle"] ."</td>
                    <td align=\"center\"><label style=\"float:left\"></label>". $vTranscaja[$i]["fecha"] ."</td>
                    <td align=\"right\"><label style=\"float:left\">L.</label>". $vTranscaja[$i]["monto"] ."</td>
                </tr>";
            $tot_devs += (float)$vTranscaja[$i]["monto"];
        }    
    }
?> 
    <tr bgcolor="#F2F2F2">
            <td><center><b>Totales</b></center></td>        
            <td align="right"></td>
            <td align="right"><b><label style="float:left;">L.</label><?= number_format((float)$tot_devs,2) ?></b></td>   
    </tr>
    </table>

<br />

    <table width="100%" cellspacing="0" cellpadding="3" border="1">
        <tr><td colspan="3"><label>Gastos</label></td></tr>
        <tr style="background-color:#D8D8D8; color:black">
            <th width="42%">Detalle</th>
            <th>Fecha</th>
            <th>Monto</th>
        </tr>
<?php
    $tot_gastos = 0;
    for($i=0;$i<count($vTranscaja); $i++){
        if((int)$vTranscaja[$i]["tipo"]==2){
            echo "<tr>
                    <td align=\"left\">" . $vTranscaja[$i]["detalle"] ."</td>
                    <td align=\"center\"><label style=\"float:left\"></label>". $vTranscaja[$i]["fecha"] ."</td>
                    <td align=\"right\"><label style=\"float:left\">L.</label>". $vTranscaja[$i]["monto"] ."</td>
                </tr>";
            $tot_gastos += (float)$vTranscaja[$i]["monto"];
        }    
    }
?> 
    <tr bgcolor="#F2F2F2">
            <td><center><b>Totales</b></center></td>        
            <td align="right"></td>
            <td align="right"><b><label style="float:left;">L.</label><?= number_format((float)$tot_gastos,2) ?></b></td>   
    </tr>
    </table>

<br />
    <?php
        $vDeposito = 0;
        $vDeposito = $vTotalFacs - ($vTarjeta + $tot_gastos + $tot_devs);
    ?>
    <label style="font-size: 1.2em; font-weight: bold;">Detalle Deposito</label>
    <table width="100%" cellspacing="0" cellpadding="3" border="1" style="margin-top: 5px">
        <tr><td>Total Facturado</td><td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vTotalFacs,2) ?></b></td></tr>
        <tr><td>Total Tarjeta</td><td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vTarjeta,2) ?></b></td></tr>
        <tr><td>Total Gastos</td><td align="right" style="color:red"><b><label style="float:left">L.</label><?= number_format((float)$tot_gastos,2) ?></b></td></tr>
        <tr><td>Total Dev/Venta</td><td align="right" style="color:red"><b><label style="float:left">L.</label><?= number_format((float)$tot_devs,2) ?></b></td></tr>
        <tr bgcolor="#F2F2F2"><td><b><i>MONTO A DEPOSITAR</i></b></td><td align="right"><b><label style="float:left">L.</label><?= number_format((float)$vDeposito,2) ?></b></td></tr>
    </table>

    <br />

    <table width="100%" cellspacing="0" cellpadding="3" border="1">
        <tr><td colspan="3"><label>Detalle de Ventas Por Vendedor</label></td></tr>
        <tr style="background-color:#D8D8D8; color:black">
            <th width="42%">Vendedor</th>
            <th>Dev/Ventas</th>
            <th>Facturación</th>
        </tr>
<?php
    
    for($i=0;$i<count($vVtasVendedores); $i++){
            echo "<tr>
                    <td align=\"left\">" . $vVtasVendedores[$i]["vendedor"] ."</td>
                    <td align=\"right\"><label style=\"float:left\">L.</label>". $vVtasVendedores[$i]["devs"] ."</td>
                    <td align=\"right\"><label style=\"float:left\">L.</label>". $vVtasVendedores[$i]["facs"] ."</td>
                </tr>";   
    }
?> 
    <!--<tr bgcolor="#F2F2F2">
            <td><center><b>Totales</b></center></td>        
            <td align="right"></td>
            <td align="right"><b><label style="float:left;">L.</label><?= number_format((float)$tot_gastos,2) ?></b></td>   
    </tr>-->
    </table>
</div>
</body>

<script type="text/javascript" src="../../js/jquery-3.1.1.min.js"></script>
<!--<script type="text/javascript" src="cordova.js"></script>-->

<script src="../../js/angular.min.js"></script>
<script type="text/javascript">    
   window.print();
</script>

</html>
